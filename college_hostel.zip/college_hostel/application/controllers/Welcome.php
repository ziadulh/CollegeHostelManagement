<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	 public function __construct()
        {
                // Call the CI_Model constructor
                parent::__construct();
                $this->load->model('StudentModel');

        }
        
	public function index()
	{
		$this->load->view('home');
	}

	public function student_info()
	{
		$this->load->view('student/student_view');
	}

	public function register_student()
	{
		$this->load->view('student/student_register_view');
	}
	public function registration_student()
	{
		$this->data ['records'] = $this->StudentModel->show_registered_students();
		$this->load->view('student/student_record_view',$this->data);
	}

	public function allocateRoom_student()
	{
		$this->load->view('student/student_room_view');
	}
	public function all_my_info_student()
	{
		$this->load->view('student/student_record_by_id_view');
	}
	public function daily_meal_student()
	{
		$this->load->view('student/student_meal_view');
	}
	public function my_room_student()
	{
		$this->load->view('student/student_record_by_room_view');
	}


	public function save_student_registration(){
		if($this->StudentModel->save_std_info()){
			$this->load->view('student/student_reg_success_view');
		}
		else 
			redirect('/welcome');
	}


	public function select_rooms(){
		$this->data['my_enrolled_room'] = $this->StudentModel->show_my_room();
		$this->load->view('student/my_room_view',$this->data);
	}


	public function show_my_record(){

		$this->data['my_enrolled_rec'] = $this->StudentModel->show_my_record();
		$this->load->view('student/my_record_view',$this->data);
	}

	public function show_my_room_record(){
		$this->data['my_enrolled_rec'] = $this->StudentModel->show_my_room_record();
		$this->load->view('student/my_room_record_view',$this->data);

	}

	


}
