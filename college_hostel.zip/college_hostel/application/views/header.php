<div id ="container" style="background:#4682B4">



<header>
	<p align ="center">
	<!-- <img src="images/hostel.jpg" alt="College Hostel" width="450" height = "90" /> -->
	<img src="<?php echo base_url();?>images/hostel.jpg" alt="Header" width="450" height = "90" />
	<!--
	<ul>
				<li class="current"><a href="<?php echo site_url('welcome/index');?>"><span>Home</span></a></li>
				<li><a href="student/student_view.html"><span>Student</span></a></li>
				<li><a href="employee/employees_view.html"><span>Employees</span></a></li>
				<li><a href="department/department_view.html"><span>Department</span></a></li>
			</ul>
	
	</p> -->
<br><br>
	
	<!--			<img src="<?php echo base_url();?>images/home.jpg" alt="Header" width="300" height = "150" />
				<img src="<?php echo base_url();?>images/student.jpg" alt="Keys" width="300" height = "150"/>
				<img src="<?php echo base_url();?>images/employees.jpg" alt="Header" width="300" height = "150" />
				<img src="<?php echo base_url();?>images/department.jpg" alt="Keys" width="300" height = "150"/>    -->


				<a href="<?php echo site_url('welcome/index');?>"><img src="<?php echo base_url();?>images/home.jpg" alt="Header" width="300" height = "150" /></a></li>
				<a href="<?php echo site_url('welcome/student_info');?>"><img src="<?php echo base_url();?>images/student.jpg" alt="Keys" width="300" height = "150"/></a></li>
				<a href="<?php echo site_url('welcome/index');?>"><img src="<?php echo base_url();?>images/employees.jpg" alt="Header" width="300" height = "150" /></a></li>
				<a href="<?php echo site_url('welcome/index');?>"><img src="<?php echo base_url();?>images/department.jpg" alt="Keys" width="300" height = "150"/></a></li>  
			

</header>