<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<!-- Website template by freewebsitetemplates.com -->
<html>


<head>
	<meta charset="utf-8">
	<title>Home</title>

	<style type="text/css">

	::selection { background-color: #E13300; color: white; }
	::-moz-selection { background-color: #E13300; color: white; }

	body {
		background-color: #fff;
		margin: 40px;
		font: 15px/25px normal Helvetica, candara, sans-serif;
		color: black;
	}

	a {
		color: #003399;
		background-color: transparent;
		font-weight: normal;
	}

	h1 {
		color: #444;
		background-color: transparent;
		border-bottom: 1px solid #D0D0D0;
		font-size: 19px;
		font-weight: normal;
		margin: 0 0 14px 0;
		padding: 14px 15px 10px 15px;
	}

	code {
		font-family: Consolas, Monaco, Courier New, Courier, monospace;
		font-size: 12px;
		background-color: #f9f9f9;
		border: 1px solid #D0D0D0;
		color: #002166;
		display: block;
		margin: 14px 0 14px 0;
		padding: 12px 10px 12px 10px;
	}


	#body {
		margin: 0 15px 0 15px;
	}

	p.footer {
		text-align: right;
		font-size: 11px;
		border-top: 1px solid #D0D0D0;
		line-height: 32px;
		padding: 0 10px 0 10px;
		margin: 20px 0 0 0;
	}

	#container {
		margin: 10px;
		border: 1px solid #D0D0D0;
		box-shadow: 0 0 8px #D0D0D0;
	}
	#table-wrapper {
		  position:relative;
		}
	
	#table-wrapper table {
		  width:75%;
		    
		}

	#table-wrapper th {
		    background-color: #0033cc;
		    color: white;
		}
	#table-wrapper tr:nth-child(even){
			background-color: #99b1ff;
		}
	
	#table-wrapper table thead th .text {
		  position:absolute;   
		  top:-20px;
		  z-index:2;
		  height:20px;
		  width:35%;
		  border:1px solid red;
		}
	</style>
</head>


<body>
	<?php $this->load->view('header');?>




<div id="container" style = "background:lightgrey">
	<h1 align = "center">Daily Meal Package</h1>
	
	<h3>
		This page is for student meal packages and cost details. Students can choice any meal package by using their ID. The meal package along with cost details is in a scrollable table. It is geretated dynamically. The dropdown box contains the same
		meals of that list. You have to select one after providing your Student_id and press Go. It's done. This 
		Query will store the whole process in the (meal) table of our database.
		</h3>
		
		
		<span class="numbers">
<div id="table-wrapper">
  <div id="table-scroll">
	<table align="right" border="1" style = "border-collapse:collapse">
		<thead>
			<th>No.</th>
			<th>Meal Code</th>
			<th>Package Details</th>
			<th>Daily Cost</th>
			<th>Monthly Cost</th>
			</thead>
		
		<tbody>
			<?php 
			$counter=1;
			foreach($meals as $meal){;?>
			<tr>
				<td><?php echo $counter;?></td>
				<td><?php echo $meal['course_code'];?></td>
				<td><?php echo $meal['section'];?></td>
				<td><?php echo $meal['initial'];?></td>
				<td><?php echo $meal['day'];?></td>
				<td><?php echo $meal['time'];?></td>
				<td><?php echo $meal['enrolled_count'].'/'.$course['capacity'];?></td>

				</tr>

			<?php
				$counter++;
				};?>


		</tbody>
	</table>
	 </div>
</div>
</span>

<form name="select_meals" method="post" action="http://localhost/college_hostel/index.php/admin/save_select_meals">
				<p align="center">
					<strong>Student ID</strong>
					<input type="text" name="student_id" placeholder="Student ID" required="required"/>
				</p>

				<p align="center">
					<strong>Meal</strong>
					<select name="meal_code" required>			<!--This select name is important-->
					<option value="">Select a Meal</option>
					 
						
						<option value="4"> 1 </option>
						 
						
						<option value="12"> 2 </option>
						 
						
						<option value="5"> 3 </option>
						 
						
						<option value="6"> 4 </option>
						 
						
						<option value="7"> 5 </option>
						 
						
						
							
					
					</select>
				</p>
				<p align="center">
					<input type="submit" name="submit" value="Save" />
				</p>
			</form>

</div>

	
		
	<div id= "container" style="background:#A9A9A9">
	<p align="right">All Rights Reserved By unknown;2016</p>
	<p class="footer"><a href="<?php echo site_url('welcome/index');?>">Go to Home</a></p>
</div></div>

</body>
</html>