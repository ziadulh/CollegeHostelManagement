<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class StudentModel extends CI_Model {

        public $student_id;

        public function __construct()
        {
                // Call the CI_Model constructor
                parent::__construct();
        }

    public function save_std_info(){
             $data = array
            (
                'f_name' => $this->input->post('fname'),
                'l_name' => $this->input->post('lname'),
                 'father_name' => $this->input->post('fathername'),
                'mother_name' => $this->input->post('mothername'),
                 'dob' => $this->input->post('bday'),
                'gender' => $this->input->post('gender'),
                'email' => $this->input->post('email'),
                'contact' => $this->input->post('contactno'),


            );
                
                if($this->db->insert('student_info',$data))
                        return TRUE;
                else
                        return FALSE;
    }


    public function show_my_room(){
            $this->student_id    = $this->input->post('stu_id');
            

            return $this->db->where('s.stu_id', $this->student_id)
                        ->select('r.room_no, r.room_details, r.room_cost,s.l_name,s.stu_id,s.f_name,r.room_allocation_id')
                        ->from('student_info as s')
                        ->join('room_allocation as r','r.room_no=s.room_no')
                        ->get()->result_array();

        }

        public function show_my_record(){

            $this->student_id    = $this->input->post('stu_id');
            return $this->db->where('s.stu_id', $this->student_id)

            ->select('s.stu_id, s.f_name, s.l_name,r.room_no,m.meal_no,r.room_cost,m.meal_cost,r.room_details,s.father_name,s.mother_name,s.dob,s.email,s.contact,s.gender,m.meal_details')
            ->from('student_info as s')
            ->join('room_allocation as r','r.room_no=s.room_no')
            ->join('meal_info as m', 'm.meal_no=s.meal_no')

            ->get()->result_array();


        }


        public function show_my_room_record(){

            $this->room_no    = $this->input->post('room_no');
            return $this->db->where('s.room_no', $this->room_no)
            ->select('s.stu_id, s.f_name, s.l_name,s.email,s.contact,s.gender,r.room_details')
            ->from('student_info as s')
            ->join('room_allocation as r', 'r.room_no=s.room_no')

            ->get()->result_array();

        }

        public function show_registered_students(){
              return $this->db->select('s.stu_id, s.f_name, s.l_name,r.room_no,m.meal_no,r.room_cost,m.meal_cost,r.room_details,s.father_name,s.mother_name,s.dob,s.email,s.contact,s.gender,m.meal_details')
            ->from('student_info as s')
            ->join('room_allocation as r','r.room_no=s.room_no')
            ->join('meal_info as m', 'm.meal_no=s.meal_no')

            ->get()->result_array();
        }


    


}